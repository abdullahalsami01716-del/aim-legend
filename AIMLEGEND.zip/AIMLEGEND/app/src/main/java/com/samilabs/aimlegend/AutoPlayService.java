import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.Toast;

public class AutoPlayService extends AccessibilityService {

    public static AutoPlayService instance;
    private WindowManager windowManager;
    private View overlayView;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        showFloatingOverlay();
    }

    // ফ্লোটিং ওভারলে উইন্ডো স্ক্রিনে শো করার মেথড
    private void showFloatingOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        LayoutInflater inflater = LayoutInflater.from(this);
        overlayView = inflater.inflate(R.layout.overlay_layout, null);

        // ওভারলে প্যারামিটার (Android ভার্সন অনুযায়ী সিস্টেম ওভারলে টাইপ)
        int LAYOUT_FLAG;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        // ওভারলে উইন্ডোর পজিশন (স্ক্রিনের উপরে ডানপাশে বা মাঝখানে)
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 200;

        // ওভারলে ভিউ এর ভেতরের প্লে বাটন কন্ট্রোল
        Button btnOverlayPlay = overlayView.findViewById(R.id.btnOverlayPlay);
        btnOverlayPlay.setOnClickListener(v -> {
            Toast.makeText(this, "Aim Legend Play Clicked!", Toast.LENGTH_SHORT).show();
            // এখানে অটো-শট বা ট্রিগার ফাংশন কল করতে পারবেন
            executeAutoShot(300, 800, 300, 400); 
        });

        // WindowManager এ ভিউ যোগ করা
        windowManager.addView(overlayView, params);
    }

    // স্ক্রিনে অটো সোয়াইপ/শট করার ফাংশন
    public void executeAutoShot(float startX, float startY, float endX, float endY) {
        Path swipePath = new Path();
        swipePath.moveTo(startX, startY);
        swipePath.lineTo(endX, endY);

        GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
        gestureBuilder.addStroke(new GestureDescription.StrokeDescription(swipePath, 0, 100));

        dispatchGesture(gestureBuilder.build(), null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayView != null && windowManager != null) {
            windowManager.removeView(overlayView);
        }
    }
}