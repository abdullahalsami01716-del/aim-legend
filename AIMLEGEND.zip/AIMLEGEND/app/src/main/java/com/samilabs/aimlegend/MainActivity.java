package com.samilabs.aimlegend;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLaunchCarrom = findViewById(R.id.btnLaunchCarrom);
        Button btnStartService = findViewById(R.id.btnStartService);

        // ১. অ্যাপের ভেতর থেকে সরাসরি Carrom Pool গেম লঞ্চ করা
        btnLaunchCarrom.setOnClickListener(v -> {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.miniclip.carrom");
            if (intent != null) {
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Carrom Pool is not installed!", Toast.LENGTH_SHORT).show();
            }
        });

        // ২. ওভারলে পারমিশন চেক করে সার্ভিস (ফ্লোটিং উইন্ডো) চালু করা
        btnStartService.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                // যদি পারমিশন না থাকে, তবে সেটিংস পেজে নিয়ে যাবে
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                Toast.makeText(this, "Please allow overlay permission", Toast.LENGTH_SHORT).show();
            } else {
                // পারমিশন দেওয়া থাকলে ব্যাকগ্রাউন্ড সার্ভিস ও ওভারলে চালু হবে
                Intent serviceIntent = new Intent(MainActivity.this, AutoPlayService.class);
                startService(serviceIntent);
                Toast.makeText(this, "AIM Legend Overlay Started!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}